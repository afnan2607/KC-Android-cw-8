package com.example.myafn7;

import java.io.Serializable;

public class Items implements Serializable {
    private String itemsName;
    private int itemImage;
    private double itemsPrice;


    public Items(String itemsName, int itemImage, double itemsPrice) {
        this.itemsName = itemsName;
        this.itemImage = itemImage;
        this.itemsPrice = itemsPrice;
    }

    public String getItemsName() {
        return itemsName;
    }

    public void setItemsName(String itemsName) {
        this.itemsName = itemsName;
    }

    public int getItemImage() {
        return itemImage;
    }

    public void setItemImage(int itemImage) {
        this.itemImage = itemImage;
    }

    public double getItemsPrice() {
        return itemsPrice;
    }

    public void setItemsPrice(double itemsPrice) {
        this.itemsPrice = itemsPrice;
    }
}
