package com.example.myafn7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class details_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Bundle bundle = getIntent().getExtras();
        Items delieveredItems =(Items) bundle.getSerializable("Items");

        TextView textView = findViewById(R.id.textView);
        ImageView imageView =findViewById(R.id.imageView2);

        textView.setText(String.valueOf( delieveredItems.getItemsName()));
        imageView.setImageResource(delieveredItems.getItemImage());







    }
}