package com.example.myafn7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Items> itemsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Items cheese = new Items("cheese",R.drawable.cheese,3.8);
        Items chocolate = new Items("chocolate",R.drawable.chocolate,2.0);
        Items coffee = new Items("cofee",R.drawable.coffee,5.9);
        Items honey = new Items("honey",R.drawable.honey,6.7);


        itemsList.add(cheese);
        itemsList.add(chocolate);
        itemsList.add(coffee);
        itemsList.add(honey);


        ItemsAdapter itemsAdapter =new ItemsAdapter(this,0,itemsList);
        ListView listView = findViewById(R.id.listView);

        listView.setAdapter(itemsAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

               Items currentitems = itemsList.get(i);
               Intent intent = new Intent(MainActivity.this, details_Activity.class);
               intent.putExtra("Items",currentitems);
               startActivity(intent);


            }
        });

    }


}